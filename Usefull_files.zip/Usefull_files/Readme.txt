Percentages:

10 - 71.83 %
12 - 64.1 %
Degree - 62.77 %
Mca - 75.41 %

Dwp joing date : 25-03-2015 - till date


