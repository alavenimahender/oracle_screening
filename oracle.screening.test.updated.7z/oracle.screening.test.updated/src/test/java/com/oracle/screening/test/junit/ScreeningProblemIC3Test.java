package com.oracle.screening.test.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.oracle.screening.test.constant.ScreeningProblemConstant;
import com.oracle.screening.test.model.Customer;
import com.oracle.screening.test.service.ScreeningProblemService;
import com.oracle.screening.test.service.ScreeningProblemServiceImpl;
import com.oracle.screening.test.service.util.ScreeningTestUtil;

/**
 * Screening Problem IC3 Junit Test
 * The number of unique customerId for each contractId.
 * The number of unique customerId for each geozone.
 * The average build duration for each geozone.
 * The list of unique customerId for each geozone.
 * @author mahender.alaveni
 * @since 1.0
 */
public class ScreeningProblemIC3Test{
  /* --------------------------------------------------------------- */
  /*                       declarations                              */
  /* --------------------------------------------------------------- */
  private ScreeningProblemService screeningProblemService;
  private ScreeningTestUtil screeningTestUtil;
  List<String> headers;
  String customersData;

  /* --------------------------------------------------------------- */
  /*                       setup method                              */
  /* --------------------------------------------------------------- */
  @BeforeEach
  public void setUp() throws Exception {
    screeningProblemService = new ScreeningProblemServiceImpl();
    screeningTestUtil = new ScreeningTestUtil();
    headers = screeningTestUtil.getHeaders();
    customersData = screeningProblemService.getCustomersData(ScreeningProblemConstant.FILE_PATH);
  }

  /**
   * Get customer list test
   */
  @SuppressWarnings("static-access")
  @Test
  @DisplayName("Get customer list test")
  public void getCustomersTest() {
    List<Customer> listCustomer = screeningProblemService.getCustomers(customersData, headers);
    System.out.println(listCustomer.get(0));
    List<Customer> mockListCustomer = getCustomerList();
    assertEquals(listCustomer.get(0).getCustomerId(), mockListCustomer.get(0).getCustomerId(),
        "Get customer list test");
  }

  @SuppressWarnings("unlikely-arg-type")
  @Test
  @DisplayName("Number Of Unique CustomerId For Each ContractId")
  public void getNumberOfUniqueCustomerIdForEachContractIdTest() {
    List<Customer> listCustomer = screeningProblemService.getCustomers(customersData, headers);
    Map<Integer, Long> numberOfUniqueCustomerIdForEachContractId = screeningProblemService
        .getNumberOfUniqueCustomerIdForEachContractId(listCustomer);
    Map<Integer, Long> mockNumberOfUniqueCustomerIdForEachContractId = getNumberOfUniqueCustomerIdForEachContractId();
    assertEquals(numberOfUniqueCustomerIdForEachContractId.get("2345"),
        mockNumberOfUniqueCustomerIdForEachContractId.get("2345"), "Number Of Unique CustomerId For Each ContractId");
  }

  @Test
  @DisplayName("Number Of Unique CustomerId For Each GeoZone")
  public void getNumberOfUniqueCustomerIdForEachGeoZoneTest() {
    List<Customer> listCustomer = screeningProblemService.getCustomers(customersData, headers);
    Map<Object, Long> numberOfUniqueCustomerIdForEachGeoZone = screeningProblemService
        .getNumberOfUniqueCustomerIdForEachGeoZone(listCustomer);
    Map<Object, Long> mockNumberOfUniqueCustomerIdForEachGeoZone = getNumberOfUniqueCustomerIdForEachGeoZone();
    assertEquals(numberOfUniqueCustomerIdForEachGeoZone.get("us_west"),
        mockNumberOfUniqueCustomerIdForEachGeoZone.get("us_west"), "Number Of Unique CustomerId For Each ContractId");
  }

  /* --------------------------------------------------------------- */
  /*                       helper mock method                        */
  /* --------------------------------------------------------------- */
  List<Customer> getCustomerList() {
    List<Customer> listCutomer = new ArrayList<Customer>();
    Customer customer = new Customer();
    customer.setBuildDuration(3445);
    customer.setContractId(2345);
    customer.setCustomerId(2343225);
    customer.setGeoZone("us_east");
    customer.setProjectCode("ProjectApple");
    customer.setTeamCode("RedTeam");
    listCutomer.add(customer);
    return listCutomer;
  }

  Map<Integer, Long> getNumberOfUniqueCustomerIdForEachContractId() {
    Map<Integer, Long> map = new HashMap<>();
    map.put(2345, Long.valueOf(3));
    map.put(2346, Long.valueOf(2));
    return map;
  }

  Map<Object, Long> getNumberOfUniqueCustomerIdForEachGeoZone() {
    Map<Object, Long> map = new HashMap<>();
    map.put("eu_west", Long.valueOf(2));
    map.put("us_west", Long.valueOf(2));
    map.put("us_east", Long.valueOf(1));
    return map;
  }
}
