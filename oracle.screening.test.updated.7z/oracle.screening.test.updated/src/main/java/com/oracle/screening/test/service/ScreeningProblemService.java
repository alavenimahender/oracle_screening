package com.oracle.screening.test.service;

import java.util.List;
import java.util.Map;

import com.oracle.screening.test.model.Customer;

/**
 * Screening problem service
 * @author mahender.alaveni
 * @since 1.0
 */
public interface ScreeningProblemService{
  String getCustomersData(String filePath);
  List<Customer> getCustomers(String customersData, List<String> headers);
  Map<Integer, Long> getNumberOfUniqueCustomerIdForEachContractId(List<Customer> customerList);
  Map<Object, Long> getNumberOfUniqueCustomerIdForEachGeoZone(List<Customer> customerList);
  Map<Object, Double> getAverageBuildDurationForEachContractId(List<Customer> customerList);
  Map<Object, List<Customer>> listOfUniqueCustomerIdForEachGeoZone(List<Customer> customerList);
}
