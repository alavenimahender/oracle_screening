package com.oracle.screening.test.exception;

/**
 * Screening problem service exception
 * @author Mahender Alaveni
 * @since 1.0
 */
public class ScreeningProblemServiceException extends RuntimeException{
  /* --------------------------------------------------------------- */
  /*                       Declarations                              */
  /* --------------------------------------------------------------- */
  private static final long serialVersionUID = 1L;

  /* --------------------------------------------------------------- */
  /*                        constructor                              */
  /* --------------------------------------------------------------- */
  public ScreeningProblemServiceException(final String problem) {
    super(problem);
  }

}
