package com.oracle.screening.test.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import  com.oracle.screening.test.constant.ScreeningProblemConstant;
import com.oracle.screening.test.exception.ScreeningProblemServiceException;
import com.oracle.screening.test.model.Customer;
import com.oracle.screening.test.service.util.CustomerWrapper;

/**
 * Screening problem service impl
 * The number of unique customerId for each contractId.
 * The number of unique customerId for each geozone.
 * The average build duration for each geozone.
 * The list of unique customerId for each geozone.
 * @author mahender.alaveni
 * @since 1.0
 */
public class ScreeningProblemServiceImpl implements ScreeningProblemService{
  /* --------------------------------------------------------------- */
  /*                        Override methods                         */
  /* --------------------------------------------------------------- */
  /**
   * Get the customer data
   * @param personData
   * @param headers
   * @return
   * @throws IOException 
   */
  @Override
  public String getCustomersData(String filePath) {
    InputStream is = null;
    String customerData = null;
    try {
      is = ScreeningProblemServiceImpl.class.getResourceAsStream(ScreeningProblemConstant.FILE_PATH);
      customerData = new String(is.readAllBytes());
    } catch (IOException ioe) {
      throw new ScreeningProblemServiceException(ioe.getMessage());
    }
    return customerData;
  }

  /**
   * Get the customer list
   * @param personData
   * @param headers
   * @return
   */
  @Override
  public List<Customer> getCustomers(String personData, List<String> headers) {
    List<Customer> customerList = new ArrayList<Customer>();
    Stream<String> streamList = Arrays.stream(personData.split("\n"));
    streamList.forEach(stream-> {
      Stream<String> rowData = Arrays.stream(stream.split(","));
      Customer customer = getCustomer(headers, rowData);
      customerList.add(customer);
    });
    return customerList;
  }

  /**
   * Gets the number of unique customer id for each contract id
   * @param customerList
   * @return
   */
  @Override
  public Map<Integer, Long> getNumberOfUniqueCustomerIdForEachContractId(List<Customer> customerList) {
    Map<Integer, Long> list = customerList.stream().map(customer-> new CustomerWrapper(customer)).distinct()
        .map(wrapper-> wrapper.customer)
        .collect(Collectors.groupingBy(customer-> customer.getContractId(), Collectors.counting()));
    list.forEach((contractId, count)-> {
      System.out.println("contractId:" + contractId + ":" + count);
    });
    return list;
  }

  /**
   * Gets the number of unique customer id for each geo zone
   * @param customerList
   * @return
   */
  @Override
  public Map<Object, Long> getNumberOfUniqueCustomerIdForEachGeoZone(List<Customer> customerList) {
    Map<Object, Long> list = customerList.stream().map(customer-> new CustomerWrapper(customer)).distinct()
        .map(wrapper-> wrapper.customer)
        .collect(Collectors.groupingBy(customer-> customer.getGeoZone(), Collectors.counting()));
    list.forEach((geoZone, count)-> {
      System.out.println("geoZone:" + geoZone + ":" + count);
    });
    return list;
  }

  /**
   * Gets the average build duration for each contract id
   * @param customerList
   * @return
   */
  @Override
  public Map<Object, Double> getAverageBuildDurationForEachContractId(List<Customer> customerList) {
    Map<Object, Double> list = customerList.stream().map(customer-> new CustomerWrapper(customer)).distinct()
        .map(wrapper-> wrapper.customer).collect(Collectors.groupingBy(customer-> customer.getContractId(),
            Collectors.averagingDouble(customer-> customer.getBuildDuration())));
    list.forEach((contractId, average)-> {
      System.out.println("contractId: " + contractId + ":" + average);
    });
    return list;
  }

  /**
   * Gets the list of unique customer id for each geo zone
   * @param customerList
   * @return
   */
  @Override
  public Map<Object, List<Customer>> listOfUniqueCustomerIdForEachGeoZone(List<Customer> customerList) {
    Map<Object, List<Customer>> list = customerList.stream().map(customer-> new CustomerWrapper(customer)).distinct()
        .map(wrapper-> wrapper.customer)
        .collect(Collectors.groupingBy(customer-> customer.getGeoZone(), Collectors.toList()));
    list.forEach((geoZone, listOfCustomer)-> {
      listOfCustomer.forEach(customer-> System.out.println("geoZone:" + geoZone + ":" + customer.getCustomerId()));
    });
    return list;
  }
  /* --------------------------------------------------------------- */
  /*                          Helper methods                         */
  /* --------------------------------------------------------------- */

  /**
   * Get's the customer
   * @param headers
   * @param rowData
   * @return
   */
  private Customer getCustomer(List<String> headers, Stream<String> rowData) {
    AtomicInteger ordinal = new AtomicInteger(0);
    Map<String, String> keyValue = new HashMap<>();
    rowData.forEach(data-> {
      keyValue.put(headers.get(ordinal.getAndIncrement()), data);
    });
    return getCustomer(keyValue);
  }

  /**
   * Gets the customer info
   * @param keyValue
   * @return
   */
  private static Customer getCustomer(Map<String, String> keyValue) {
    Customer customer = new Customer();
    customer.setCustomerId(Integer.valueOf(keyValue.get("customerId")));
    customer.setContractId(Integer.valueOf(keyValue.get("contractId")));
    customer.setGeoZone(keyValue.get("geoZone"));
    customer.setTeamCode(keyValue.get("teamCode"));
    customer.setProjectCode(keyValue.get("projectCode"));
    customer.setBuildDuration(Integer.parseInt(keyValue.get("buildDuration").trim()));
    return customer;
  }


}
