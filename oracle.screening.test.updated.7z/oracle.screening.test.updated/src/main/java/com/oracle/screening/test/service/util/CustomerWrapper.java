package com.oracle.screening.test.service.util;

import java.util.Objects;

import com.oracle.screening.test.model.Customer;
/**
 * Customer wrapper
 * @author mahender.alaveni
 * @since 1.0
 */
public class CustomerWrapper{
  /* --------------------------------------------------------------- */
  /*                      constructor                                */
  /* --------------------------------------------------------------- */
  public Customer customer;

  public CustomerWrapper(Customer customer) {
    this.customer = customer;
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof CustomerWrapper))
      return false;
    CustomerWrapper other = (CustomerWrapper) obj;
    return Objects.equals(customer.getCustomerId(), other.customer.getCustomerId())
        && customer.getContractId() == other.customer.getContractId();
  }

  @Override
  public int hashCode() {
    return 1;
  }
}
