package com.oracle.screening.test.constant;

public class ScreeningProblemConstant{
  public static final String FILE_PATH = "/Screening_problem_IC3.txt";
}
