package com.oracle.screening.test.service.util;

import java.util.Arrays;
import java.util.List;


/**
 * Screening test util
 * @author mahender.alaveni
 * @since 1.0
 */
public class ScreeningTestUtil{
  /* --------------------------------------------------------------- */
  /*                          Helper methods                         */
  /* --------------------------------------------------------------- */

  /**
   * Get's the list of headers
   * @return
   */
  public List<String> getHeaders() {
    return Arrays.asList("customerId", "contractId", "geoZone", "teamCode", "projectCode", "buildDuration");
  }
}
