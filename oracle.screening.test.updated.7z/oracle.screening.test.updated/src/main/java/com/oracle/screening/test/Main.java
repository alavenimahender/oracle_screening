package com.oracle.screening.test;

import java.util.List;
import java.util.Map;

import com.oracle.screening.test.constant.ScreeningProblemConstant;
import com.oracle.screening.test.model.Customer;
import com.oracle.screening.test.service.ScreeningProblemService;
import com.oracle.screening.test.service.ScreeningProblemServiceImpl;
import com.oracle.screening.test.service.util.ScreeningTestUtil;

/**
 * Main to execute the hole stuff
 * @author mahender.alaveni
 * @since 1.0
 */
public class Main{
  static ScreeningTestUtil screeningTestUtil = null;
  static ScreeningProblemService screeningProblemService = null;

  public static void main(String[] args) {
    String customersData = getScreeningProblemService().getCustomersData(ScreeningProblemConstant.FILE_PATH);
    List<Customer> customerList = getScreeningProblemService().getCustomers(customersData,
        getScreeningTestUtil().getHeaders());
    Map<Integer, Long> numberOfUniqueCustomerIdForEachContractId = getScreeningProblemService()
        .getNumberOfUniqueCustomerIdForEachContractId(customerList);
    System.out.println(
        "\nThe number of unique customerId for each contractId:" + numberOfUniqueCustomerIdForEachContractId + "\n");
    Map<Object, Long> numberOfUniqueCustomerIdForEachGeoZone = getScreeningProblemService()
        .getNumberOfUniqueCustomerIdForEachGeoZone(customerList);
    System.out
        .println("\nThe number of unique customerId for each geozon:" + numberOfUniqueCustomerIdForEachGeoZone + "\n");
    Map<Object, Double> averageBuildDurationForEachContractId = getScreeningProblemService()
        .getAverageBuildDurationForEachContractId(customerList);
    System.out.println("\nThe average build duration for each geozone:" + averageBuildDurationForEachContractId + "\n");
    Map<Object, List<Customer>> listOfUniqueCustomerIdForEachGeZone = getScreeningProblemService()
        .listOfUniqueCustomerIdForEachGeoZone(customerList);
    System.out.println("\nlist of unique customerId for each geozone:" + listOfUniqueCustomerIdForEachGeZone + "\n");
  }
  /* --------------------------------------------------------------- */
  /*                       helper methods                            */
  /* --------------------------------------------------------------- */

  public static ScreeningTestUtil getScreeningTestUtil() {
    if (screeningTestUtil == null) {
      screeningTestUtil = new ScreeningTestUtil();
    }
    return screeningTestUtil;
  }

  public static ScreeningProblemService getScreeningProblemService() {
    if (screeningProblemService == null) {
      screeningProblemService = new ScreeningProblemServiceImpl();
    }
    return screeningProblemService;
  }
}