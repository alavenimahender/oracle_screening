package com.oracle.screening.test.model;

/**
 * Customer model
 * @author mahender.alaveni
 * @since 1.0
 */
public class Customer{
  private Integer customerId;
  private Integer contractId;
  private String geoZone;
  private String teamCode;
  private String projectCode;
  private Integer buildDuration;

  public Integer getCustomerId() {
    return customerId;
  }

  public void setCustomerId(Integer customerId) {
    this.customerId = customerId;
  }

  public Integer getContractId() {
    return contractId;
  }

  public void setContractId(Integer contractId) {
    this.contractId = contractId;
  }

  public String getGeoZone() {
    return geoZone;
  }

  public void setGeoZone(String geoZone) {
    this.geoZone = geoZone;
  }

  public String getTeamCode() {
    return teamCode;
  }

  public void setTeamCode(String teamCode) {
    this.teamCode = teamCode;
  }

  public String getProjectCode() {
    return projectCode;
  }

  public void setProjectCode(String projectCode) {
    this.projectCode = projectCode;
  }

  public Integer getBuildDuration() {
    return buildDuration;
  }

  public void setBuildDuration(Integer buildDuration) {
    this.buildDuration = buildDuration;
  }

  @Override
  public String toString() {
    return "Customer [customerId=" + customerId + ", contractId=" + contractId + ", geoZone=" + geoZone + ", teamCode="
        + teamCode + ", projectCode=" + projectCode + ", buildDuration=" + buildDuration + "]";
  }
}
